package models;

public class Contato {
    
}
