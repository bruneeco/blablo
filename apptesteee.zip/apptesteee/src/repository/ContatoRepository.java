package repository;

public class ContatoRepository {
    
}
